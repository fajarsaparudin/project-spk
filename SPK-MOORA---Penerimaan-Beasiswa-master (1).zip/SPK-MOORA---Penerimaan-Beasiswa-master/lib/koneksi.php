<?php
// isi nama host, username mysql, dan password mysql anda
$koneksi = new mysqli('localhost', 'root', '', 'db_moora');
?>
