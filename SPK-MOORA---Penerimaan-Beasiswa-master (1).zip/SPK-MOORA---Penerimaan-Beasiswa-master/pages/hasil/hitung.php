<div class="form-panel">
              <h4 class="mb"><i class="fa fa-angle-right"></i> Jumlah Siswa Diterima</h4>
              <form class="form-horizontal style-form" method="POST" action="pages/hasil/proses_hitung.php">
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Jumlah Siswa Diterima</label>
                  <div class="col-sm-10">
                    <input type="number" min="1" class="form-control round-form" name="jsiswa">
                  </div>
                </div>
                <div class="form-group">
                  <div class="col-sm-12" style="text-align: center;">
                    <button type="submit" class="btn btn-theme03">Masukan</button>
                    <button type="reset" class="btn btn-theme04">Reset</button>
                  </div>
              </form>
            </div>